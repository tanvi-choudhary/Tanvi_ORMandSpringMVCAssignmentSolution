package com.gl.customer.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.gl.customer.entity.Customer;

	@Service
	public interface CustomerService {

		public void save(Customer customer);
		
		public List<Customer> updateCustomer(Customer customer);

		public boolean deleteById(int Id);

		public Customer getCustomerById(int Id);

		public List<Customer> findAll();

	}

