package com.gl.customer.controller;


import com.gl.customer.service.CustomerService;
import com.gl.customer.entity.Customer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

	@Controller
	@RequestMapping("/customer")
	public class CustomerController {

		@Autowired
		private CustomerService customerService;

		@RequestMapping("/welcome")
		public String getWelcomePage() {
			return "add-customer";
		}

		@RequestMapping("/add-customer")
		public String addStudent(@ModelAttribute("customer") Customer customer) {
			customerService.save(customer);
			return "add-customer";
		}

		@RequestMapping("/showCustomer")
		public String showAllCustomer(ModelMap map) {
			 List<Customer> AllCustomer = customerService.findAll();
			 map.addAttribute("customer", AllCustomer);
			 return "printall-customer";
			 
		}
		
		@RequestMapping("/delete-customer")
		public String deleteCustomer(@RequestParam("Id") int Id, ModelMap map) {
			customerService.deleteById(Id);

			
			map.addAttribute("DeleteMsg","Customer with id " +Id+ " deleted succesfully");
			return "delete-success";
		}
		
		//For add and update person both
			@RequestMapping("/update-customer") 
			public String updateAllCustomer(@RequestParam("Id") int Id) {
				customerService.getCustomerById(Id);
				
				return "add-customer";
				
			}
		}

