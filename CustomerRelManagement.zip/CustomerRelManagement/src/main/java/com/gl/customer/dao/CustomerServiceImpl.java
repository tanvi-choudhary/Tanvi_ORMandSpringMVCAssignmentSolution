package com.gl.customer.dao;

import com.gl.customer.entity.Customer;
import com.gl.customer.service.CustomerService;
import java.util.List;

	import org.hibernate.HibernateException;
	import org.hibernate.Session;
	import org.hibernate.SessionFactory;
	import org.hibernate.Transaction;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Repository;

	@Repository
	public class CustomerServiceImpl implements CustomerService 
	{
		
		private SessionFactory sessionFactory;

		private Session session;

		@Autowired
		public CustomerServiceImpl(SessionFactory sessionFactory) {

			this.sessionFactory = sessionFactory;

			try {
				session = this.sessionFactory.getCurrentSession();
			} catch (HibernateException exception) {
				session = sessionFactory.openSession();
			}
		}

		@Override
		public void save(Customer customer) {

			Transaction txn = session.beginTransaction();
			session.save(customer);
			txn.commit();
			
			System.out.println("Customer saved with Id:" + customer.getId());
		}

		@Override
		public List<Customer> updateCustomer(Customer c) {
			
			return session.createQuery("update Customer set id="+c.getId()+", FirstName="+c.getFirstName()+",LastName="+c.getLastName()+",Email="+c.getEmail()+" where id="+c.getId(), Customer.class).getResultList();
		}
		
		@Override
		public boolean deleteById(int Id) {
			Customer customer = getCustomerById(Id);
			Transaction transaction = session.beginTransaction();
			session.delete(customer);
			transaction.commit();
			
			return true;
		}
		
		@Override
		public Customer getCustomerById(int Id) {
			return session.find(Customer.class, Id);
		}
		
		@Override
		public List<Customer> findAll() {
			return session.createQuery("from Customer", Customer.class).getResultList();
		}
		

	}	
	

